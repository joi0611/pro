'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{Store}=require('./store.cjs');
const source=process.argv[2],expected=process.argv[3];
if(!source||!/^[a-f0-9]{64}$/.test(expected||''))throw Error('Verified snapshot path and SHA256 required');
const raw=fs.readFileSync(source);if(crypto.createHash('sha256').update(raw).digest('hex')!==expected)throw Error('Snapshot checksum mismatch; database unchanged');
const snapshot=JSON.parse(raw);const db=new Store(path.join(__dirname,'private','three-sites.sqlite'));
try{const counts=db.importSnapshot(snapshot,expected);console.log(JSON.stringify({ok:true,counts,sourceExportedAt:snapshot.exported_at}));}finally{db.close();}
