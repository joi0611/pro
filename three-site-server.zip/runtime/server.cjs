'use strict';
const http=require('node:http'),crypto=require('node:crypto'),path=require('node:path'),fs=require('node:fs');
const {Store,SITES}=require('./store.cjs');
function createApp({store,secureCookies=true}={}){
 const attempts=new Map();
 return http.createServer(async(req,res)=>{
  const id='TS-'+crypto.randomUUID();res.setHeader('X-Request-Id',id);res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Cache-Control','private, no-store');
  const json=(body,code=200)=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(body));};
  const cookies=Object.fromEntries(String(req.headers.cookie||'').split(';').map(x=>x.trim().split('=')));
  const cookie=(name,value)=>res.setHeader('Set-Cookie',name+'='+value+'; Path=/three-api/; HttpOnly; SameSite=Strict; Max-Age='+(value?'604800':'0')+(secureCookies?'; Secure':''));
  try{
   const url=new URL(req.url,'http://localhost');
   if(url.pathname==='/three-api/healthz'&&req.method==='GET')return json({ok:true,service:'three-sites',databaseReady:!!store.setting('source_checksum')});
   const m=url.pathname.match(/^\/three-api\/(gzcloze|shcloze|seven_choice)\/(rpc|progress\/get|progress\/save)$/);if(!m)return json({message:'Not found'},404);
   if(req.method!=='POST')return json({message:'Method not allowed'},405);
   if(req.headers.origin&&req.headers.origin!=='https://pro.yunmianas.cn'&&req.headers.origin!=='https://national-origin.yunmianas.cn'&&req.headers.origin!=='http://'+req.headers.host)return json({message:'Origin not allowed'},403);
   let size=0,chunks=[];for await(const c of req){size+=c.length;if(size>1100000)return json({message:'Request too large'},413);chunks.push(c);}
   let p;try{p=JSON.parse(Buffer.concat(chunks).toString()||'{}');if(!p||typeof p!=='object'||Array.isArray(p))throw Error();}catch{return json({message:'Invalid JSON'},400);}
   const site=m[1],route=m[2],auth=()=>store.session(cookies['ts_'+site],'student',site);
   if(route==='progress/get'||route==='progress/save'){const s=auth();if(!s)return json({message:'登录已过期，请重新登录'},401);if(p.phone!==s.identity)return json({message:'当前页面账号已改变，请重新登录'},409);return json(route==='progress/get'?store.read(s):store.save(s,p.progress,p.revision));}
   const action=p.action,payload=p.payload&&typeof p.payload==='object'?p.payload:{};
   if(action==='student_login'||action==='admin_login'){
    const ip=req.socket.remoteAddress+':'+String(req.headers['x-forwarded-for']||'').split(',')[0].trim(),now=Date.now();let a=attempts.get(ip);if(!a||now-a.at>60000)a={at:now,n:0};a.n++;attempts.set(ip,a);if(attempts.size>10000)for(const[k,v]of attempts)if(now-v.at>60000)attempts.delete(k);if(a.n>60)return json({ok:false,msg:'请求过于频繁，请稍后再试'},429);
   }
   if(action==='student_login'){if(payload.specialty&&payload.specialty!==site)return json({ok:false,msg:'专项不匹配'},403);const r=store.login(payload.phone,site);if(!r)return json({ok:false,msg:'该手机号尚未开通本专项或授权已到期，请联系老师'});cookie('ts_'+site,r.token);return json({ok:true,phone:r.phone,specialty:site});}
   if(action==='student_logout'){store.revoke(cookies['ts_'+site]);cookie('ts_'+site,'');return json({ok:true});}
   if(action==='admin_login'){const token=await store.adminLogin(payload.password);if(!token)return json({ok:false,msg:'管理员密码错误',code:401});cookie('ts_admin',token);return json({ok:true,token:'cookie-session'});}
   if(action==='admin_logout'){store.revoke(cookies.ts_admin);cookie('ts_admin','');return json({ok:true});}
   if(!store.session(cookies.ts_admin,'admin'))return json({ok:false,msg:'请先登录管理后台',code:401},401);
   if(action==='admin_session')return json({ok:true,loggedIn:true});
   if(action==='admin_list')return json({ok:true,users:store.list(site==='seven_choice'?'*':site)});
   if(['admin_add','admin_update','admin_delete'].includes(action)){const specialty=payload.specialty||site;if(!SITES.includes(specialty)||(site!=='seven_choice'&&specialty!==site))return json({ok:false,msg:'专项不属于本次迁移范围'},403);return json(store.update(action,{...payload,specialty}));}
   return json({ok:false,msg:'Unsupported action'},400);
  }catch(e){return json({ok:false,message:e.status?e.message:'服务暂时不可用',msg:e.status?e.message:'服务暂时不可用',requestId:id},e.status||500);}
 });
}
module.exports={createApp};
if(require.main===module){const root=__dirname,store=new Store(path.join(root,'private','three-sites.sqlite'));if(!store.setting('source_checksum'))throw Error('Import a verified snapshot first');const dir=path.join(root,'private','backups');fs.mkdirSync(dir,{recursive:true});const backup=async()=>{const f=path.join(dir,'three-sites-'+new Date().toISOString().slice(0,10)+'.sqlite');if(!fs.existsSync(f))await store.backup(f);};backup().catch(()=>console.error('BACKUP_FAILED'));setInterval(()=>backup().catch(()=>console.error('BACKUP_FAILED')),3600000).unref();const app=createApp({store});app.requestTimeout=20000;app.headersTimeout=15000;app.listen(8789,'127.0.0.1',()=>console.log('three-sites ready on 127.0.0.1:8789'));}
