'use strict';
const {DatabaseSync,backup}=require('node:sqlite'),crypto=require('node:crypto'),fs=require('node:fs'),path=require('node:path');
const bcrypt=require(process.env.THREE_BCRYPT_PATH||'bcryptjs');
const SITES=['gzcloze','shcloze','seven_choice'];
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const fail=(message,status=400)=>Object.assign(Error(message),{status});
class Store{
 constructor(file){if(file!==':memory:')fs.mkdirSync(path.dirname(file),{recursive:true});this.db=new DatabaseSync(file);this.db.exec(`PRAGMA journal_mode=WAL;PRAGMA busy_timeout=5000;
 CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS phones(specialty TEXT NOT NULL,phone TEXT NOT NULL,note TEXT,enabled INTEGER NOT NULL,created_at TEXT,updated_at TEXT,expires_at TEXT,source_json TEXT,PRIMARY KEY(specialty,phone));
 CREATE TABLE IF NOT EXISTS sessions(hash TEXT PRIMARY KEY,kind TEXT NOT NULL,specialty TEXT,identity TEXT NOT NULL,expires_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS progress(specialty TEXT NOT NULL,phone TEXT NOT NULL,body TEXT NOT NULL,revision INTEGER NOT NULL,updated_at TEXT NOT NULL,PRIMARY KEY(specialty,phone));
 CREATE TABLE IF NOT EXISTS progress_history(id INTEGER PRIMARY KEY,specialty TEXT,phone TEXT,body TEXT,revision INTEGER,updated_at TEXT);
 CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,at TEXT NOT NULL,action TEXT NOT NULL,specialty TEXT,identity TEXT);`);}
 setting(k){return this.db.prepare('SELECT value FROM settings WHERE key=?').get(k)?.value;}
 importSnapshot(d,sha){
  if(this.setting('source_checksum')){if(this.setting('source_checksum')===sha)return this.counts();throw fail('Database already imported; refusing overwrite',409);}
  if(d.format!=='three-site-export-v1'||d.source_project!=='gbjmylxohacppnybfssh'||d.training_admin_config?.length!==1)throw fail('Wrong snapshot');
  this.db.exec('BEGIN IMMEDIATE');try{
   for(const p of d.training_phone_users){if(!SITES.includes(p.specialty)||!/^1[3-9]\d{9}$/.test(p.phone)||typeof p.enabled!=='boolean')throw fail('Invalid authorization');this.db.prepare('INSERT INTO phones VALUES(?,?,?,?,?,?,?,?)').run(p.specialty,p.phone,p.note||'',p.enabled?1:0,p.created_at||null,p.updated_at||null,p.expires_at||null,JSON.stringify(p));}
   this.db.prepare('INSERT INTO settings VALUES(?,?)').run('admin_hash',d.training_admin_config[0].password_hash);
   this.db.prepare('INSERT INTO settings VALUES(?,?)').run('source_checksum',sha);
   this.db.prepare('INSERT INTO settings VALUES(?,?)').run('source_exported_at',d.exported_at);
   this.db.exec('COMMIT');return this.counts();
  }catch(e){this.db.exec('ROLLBACK');throw e;}
 }
 counts(){return Object.fromEntries(SITES.map(s=>[s,Number(this.db.prepare('SELECT count(*) n FROM phones WHERE specialty=?').get(s).n)]));}
 enabled(s,p){const row=this.db.prepare('SELECT enabled,expires_at FROM phones WHERE specialty=? AND phone=?').get(s,p);return !!row?.enabled&&(!row.expires_at||Date.parse(row.expires_at)>Date.now());}
 newSession(kind,specialty,identity){const token=crypto.randomBytes(32).toString('hex');this.db.prepare('DELETE FROM sessions WHERE expires_at<=?').run(Date.now());this.db.prepare('INSERT INTO sessions VALUES(?,?,?,?,?)').run(hash(token),kind,specialty,identity,Date.now()+7*86400000);return token;}
 session(token,kind,specialty){if(!token)return null;const r=this.db.prepare('SELECT * FROM sessions WHERE hash=?').get(hash(token));return r&&r.expires_at>Date.now()&&r.kind===kind&&(kind==='admin'||r.specialty===specialty&&this.enabled(specialty,r.identity))?r:null;}
 revoke(token){this.db.prepare('DELETE FROM sessions WHERE hash=?').run(hash(token||''));}
 login(phone,s){phone=String(phone||'').replace(/[\s-]/g,'');if(!SITES.includes(s)||!/^1[3-9]\d{9}$/.test(phone)||!this.enabled(s,phone))return null;return {phone,specialty:s,token:this.newSession('student',s,phone)};}
 async adminLogin(p){if(typeof p!=='string'||p.length>128||!this.setting('admin_hash'))return null;return await bcrypt.compare(p,this.setting('admin_hash'))?this.newSession('admin','*','three-sites-admin'):null;}
 read(s){const r=this.db.prepare('SELECT body,revision,updated_at FROM progress WHERE specialty=? AND phone=?').get(s.specialty,s.identity);return r?{progress:JSON.parse(r.body),revision:r.revision,updatedAt:r.updated_at}:{progress:{},revision:0,updatedAt:null};}
 save(s,body,rev){
  if(!body||typeof body!=='object'||Array.isArray(body)||Buffer.byteLength(JSON.stringify(body))>1024*1024)throw fail('学习记录格式错误或超过大小限制');
  this.db.exec('BEGIN IMMEDIATE');try{const old=this.db.prepare('SELECT * FROM progress WHERE specialty=? AND phone=?').get(s.specialty,s.identity);if(!Number.isSafeInteger(rev)||rev!==(old?.revision||0))throw fail('其他设备已更新进度，请刷新后选择需要保留的记录',409);
   if(old)this.db.prepare('INSERT INTO progress_history(specialty,phone,body,revision,updated_at) VALUES(?,?,?,?,?)').run(s.specialty,s.identity,old.body,old.revision,old.updated_at);
   const at=new Date().toISOString(),next=rev+1;this.db.prepare('INSERT OR REPLACE INTO progress VALUES(?,?,?,?,?)').run(s.specialty,s.identity,JSON.stringify(body),next,at);
   this.db.prepare('DELETE FROM progress_history WHERE specialty=? AND phone=? AND id NOT IN(SELECT id FROM progress_history WHERE specialty=? AND phone=? ORDER BY id DESC LIMIT 20)').run(s.specialty,s.identity,s.specialty,s.identity);
   this.db.exec('COMMIT');return {ok:true,revision:next,updatedAt:at};
  }catch(e){this.db.exec('ROLLBACK');throw e;}
 }
 list(scope){const rows=scope==='*'?this.db.prepare('SELECT * FROM phones ORDER BY specialty,created_at DESC').all():this.db.prepare('SELECT * FROM phones WHERE specialty=? ORDER BY created_at DESC').all(scope);return rows.map(r=>({phone:r.phone,specialty:r.specialty,note:r.note,enabled:!!r.enabled,createdAt:r.created_at,updatedAt:r.updated_at,expiresAt:r.expires_at}));}
 update(action,p){
  const s=p.specialty,phone=String(p.phone||'');if(!SITES.includes(s)||!/^1[3-9]\d{9}$/.test(phone))throw fail('手机号或专项错误');
  const old=this.db.prepare('SELECT * FROM phones WHERE specialty=? AND phone=?').get(s,phone),now=new Date().toISOString();
  this.db.exec('BEGIN IMMEDIATE');try{
   if(action==='admin_delete'){this.db.prepare('DELETE FROM phones WHERE specialty=? AND phone=?').run(s,phone);this.db.prepare('DELETE FROM sessions WHERE kind=? AND specialty=? AND identity=?').run('student',s,phone);}
   else{if(action==='admin_update'&&!old)throw fail('账号不存在',404);if(p.enabled!==undefined&&typeof p.enabled!=='boolean')throw fail('授权状态错误');const expiry=p.expiresAt===undefined?old?.expires_at||null:p.expiresAt;if(expiry!==null&&!Number.isFinite(Date.parse(expiry)))throw fail('到期时间错误');
    this.db.prepare('INSERT INTO phones VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(specialty,phone) DO UPDATE SET note=excluded.note,enabled=excluded.enabled,updated_at=excluded.updated_at,expires_at=excluded.expires_at').run(s,phone,String(p.note===undefined?old?.note||'':p.note).slice(0,80),p.enabled===undefined?(action==='admin_add'?1:old.enabled):(p.enabled?1:0),old?.created_at||now,now,expiry,old?.source_json||'{}');
   }
   this.db.prepare('INSERT INTO audit(at,action,specialty,identity) VALUES(?,?,?,?)').run(now,action,s,phone);this.db.exec('COMMIT');return action==='admin_delete'?{ok:true}:{ok:true,user:this.list(s).find(x=>x.phone===phone)};
  }catch(e){this.db.exec('ROLLBACK');throw e;}
 }
 backup(file){return backup(this.db,file);}
 close(){this.db.close();}
}
module.exports={Store,SITES};
