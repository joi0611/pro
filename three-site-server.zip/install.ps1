param([Parameter(Mandatory=$true)][string]$PackageDirectory,[Parameter(Mandatory=$true)][string]$SnapshotPath,[Parameter(Mandatory=$true)][string]$SnapshotSha256)
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$root='C:\ProgramData\ThreeSiteTraining'
$nationalRoot='C:\ProgramData\NationalCloze'
$node=Join-Path $nationalRoot 'runtime\node.exe'
$caddy=Join-Path $nationalRoot 'https\caddy.exe'
$cfg=Join-Path $nationalRoot 'https\Caddyfile'
if (!(Test-Path -LiteralPath $node) -or !(Test-Path -LiteralPath $cfg)) { throw 'Existing verified Node/Caddy installation is required' }
$nationalHealth=Invoke-RestMethod -Uri 'http://127.0.0.1:8788/healthz' -TimeoutSec 5
if (!$nationalHealth.ok -or !$nationalHealth.databaseReady) { throw 'Existing national service is not healthy; installation stopped' }
$manifest=Get-Content -LiteralPath (Join-Path $PackageDirectory 'package-manifest.json') -Raw | ConvertFrom-Json
foreach($entry in $manifest.files.PSObject.Properties) {
  $file=Join-Path $PackageDirectory $entry.Name
  if ($entry.Name -match '(^|[\/])\.\.([\/]|$)' -or [IO.Path]::IsPathRooted($entry.Name)) { throw 'Invalid package path' }
  if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLower() -ne $entry.Value) { throw ('Package checksum mismatch: '+$entry.Name) }
}
New-Item -ItemType Directory -Path (Join-Path $root 'private') -Force | Out-Null
& icacls.exe (Join-Path $root 'private') /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Private directory permissions failed' }
$taskName='ThreeSiteTraining-Service-v1'
$task=Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
if ($task -and $task.Description -ne 'Three migrated training sites service v1') { throw 'Task ownership mismatch' }
$previousSnapshot=Join-Path $root 'private\source-snapshot.json'
if ((Test-Path -LiteralPath $previousSnapshot) -and (Get-FileHash -LiteralPath $previousSnapshot -Algorithm SHA256).Hash.ToLower() -ne $SnapshotSha256) { throw 'A different snapshot is already installed; refusing to replace active data' }
if (!$task -and @(Get-NetTCPConnection -LocalPort 8789 -State Listen -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Port 8789 is occupied by another service' }
if ($task) { Stop-ScheduledTask -TaskName $taskName }
foreach($entry in $manifest.files.PSObject.Properties) {
  if (!$entry.Name.StartsWith('runtime/')) { continue }
  $relative=$entry.Name.Substring(8)
  $dest=Join-Path $root $relative
  New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force | Out-Null
  Copy-Item -LiteralPath (Join-Path $PackageDirectory $entry.Name) -Destination $dest -Force
}
$snapshot=Join-Path $root 'private\source-snapshot.json'
if (([IO.Path]::GetFullPath($SnapshotPath)) -ne $snapshot) { Copy-Item -LiteralPath $SnapshotPath -Destination $snapshot -Force }
& $node (Join-Path $root 'import.cjs') $snapshot $SnapshotSha256
if ($LASTEXITCODE -ne 0) { if($task){Start-ScheduledTask -TaskName $taskName}; throw 'Snapshot import failed' }
$runner=@'
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process');
const log=fs.openSync(path.join(__dirname,'private','service.log'),'a');
const result=cp.spawnSync(process.execPath,[path.join(__dirname,'server.cjs')],{cwd:__dirname,stdio:['ignore',log,log]});
process.exitCode=result.status||1;
'@
[IO.File]::WriteAllText((Join-Path $root 'run-service.cjs'),$runner,(New-Object Text.UTF8Encoding($false)))
$action=New-ScheduledTaskAction -Execute $node -Argument ('"'+(Join-Path $root 'run-service.cjs')+'"') -WorkingDirectory $root
$startup=New-ScheduledTaskTrigger -AtStartup
$watchdog=New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 1)
$settings=New-ScheduledTaskSettingsSet -Hidden -StartWhenAvailable -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew
$principal=New-ScheduledTaskPrincipal -UserId 'NT AUTHORITY\SYSTEM' -LogonType ServiceAccount -RunLevel Highest
Register-ScheduledTask -TaskName $taskName -Description 'Three migrated training sites service v1' -Action $action -Trigger @($startup,$watchdog) -Settings $settings -Principal $principal -Force | Out-Null
Start-ScheduledTask -TaskName $taskName
$ready=$false
for($i=0;$i -lt 15;$i++){try{$health=Invoke-RestMethod -Uri 'http://127.0.0.1:8789/three-api/healthz' -TimeoutSec 2;if($health.ok -and $health.databaseReady){$ready=$true;break}}catch{};Start-Sleep -Seconds 1}
if(!$ready){throw 'New service did not become ready; original HTTPS routing unchanged'}
$oldConfig=[IO.File]::ReadAllText($cfg,[Text.Encoding]::UTF8)
$newConfig=$oldConfig
if(!$oldConfig.Contains('@threeSites path /three-api/*')){
  $nationalMatch=[regex]::Matches($oldConfig,'(?m)^[ \t]*@national path ')
  if($nationalMatch.Count -ne 1){throw 'Unexpected Caddy routing layout; original preserved'}
  $insert="    @threeSites path /three-api/*`r`n    handle @threeSites {`r`n        reverse_proxy 127.0.0.1:8789`r`n    }`r`n"
  $newConfig=$oldConfig.Replace($nationalMatch[0].Value,$insert+$nationalMatch[0].Value)
}
if($newConfig -ne $oldConfig){
 $candidate=Join-Path $root 'Caddyfile.candidate'
 [IO.File]::WriteAllText($candidate,$newConfig,(New-Object Text.UTF8Encoding($false)))
 $validation=Start-Process -FilePath $caddy -ArgumentList @('validate','--config',$candidate,'--adapter','caddyfile') -WindowStyle Hidden -Wait -PassThru -RedirectStandardOutput (Join-Path $root 'private\gateway-validation.stdout.log') -RedirectStandardError (Join-Path $root 'private\gateway-validation.stderr.log')
 if($validation.ExitCode -ne 0){throw 'Candidate gateway config validation failed; original preserved'}
 Copy-Item -LiteralPath $cfg -Destination (Join-Path $root ('private\Caddyfile-before-'+(Get-Date -Format 'yyyyMMddHHmmss'))) -Force
 Stop-ScheduledTask -TaskName 'NationalCloze-HTTPS-v1'
 try{[IO.File]::WriteAllText($cfg,$newConfig,(New-Object Text.UTF8Encoding($false)));Start-ScheduledTask -TaskName 'NationalCloze-HTTPS-v1'
  $tlsReady=$false
  for($i=0;$i -lt 15;$i++){try{$public=Invoke-RestMethod -Uri 'https://national-origin.yunmianas.cn/three-api/healthz' -TimeoutSec 3;$existing=Invoke-RestMethod -Uri 'http://127.0.0.1:8788/healthz' -TimeoutSec 2;if($public.ok -and $existing.ok){$tlsReady=$true;break}}catch{};Start-Sleep -Seconds 1}
  if(!$tlsReady){throw 'HTTPS readiness check failed'}
 }catch{
  Stop-ScheduledTask -TaskName 'NationalCloze-HTTPS-v1'
  [IO.File]::WriteAllText($cfg,$oldConfig,(New-Object Text.UTF8Encoding($false)))
  Start-ScheduledTask -TaskName 'NationalCloze-HTTPS-v1'
  throw
 }
}
Write-Output 'THREE_SITE_BACKEND_READY'
Write-Output 'NATIONAL_DATABASE_UNCHANGED; FRONTEND_CUTOVER_PENDING; NO_PUBLICATION_POLLING'
